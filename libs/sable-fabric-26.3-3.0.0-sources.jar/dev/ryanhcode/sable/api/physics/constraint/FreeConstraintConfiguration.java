package dev.ryanhcode.sable.api.physics.constraint;

import dev.ryanhcode.sable.api.physics.PhysicsPipelineBody;
import dev.ryanhcode.sable.api.sublevel.ServerSubLevelContainer;
import org.joml.Quaterniondc;
import org.joml.Vector3dc;

/**
 * A configuration for a free constraint, which imposes no locks
 *
 * @param pos1 the position in world space assumed to be inside the plot of the first sub-level (ex. a block position).
 * @param pos2 the position in world space assumed to be inside the plot of the second sub-level (ex. a block position).
 * @param orientation the local orientation of the second body from the first. Motor axes will be relative to this frame
 */
public record FreeConstraintConfiguration(Vector3dc pos1, Vector3dc pos2, Quaterniondc orientation) implements PhysicsConstraintConfiguration<FreeConstraintHandle> {

    @Override
    public void validate(final ServerSubLevelContainer container, final PhysicsPipelineBody bodyA, final PhysicsPipelineBody bodyB) {
        PhysicsConstraintConfiguration.validateAnchors(container, bodyA, bodyB, this.pos1, this.pos2);
    }

}