package dev.ryanhcode.sable.physics.config.block_properties;

import dev.ryanhcode.sable.Sable;
import dev.ryanhcode.sable.mixinterface.block_properties.BlockStateExtension;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ObjectList;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderSet;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.FileToIdConverter;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimpleJsonResourceReloadListener;
import net.minecraft.tags.TagKey;
import net.minecraft.util.ExtraCodecs;
import net.minecraft.util.profiling.ProfilerFiller;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;

import java.util.Collection;
import java.util.Comparator;
import java.util.Map;
import java.util.Optional;

// PORT-NOTE(mc26.1): SimpleJsonResourceReloadListener is now codec-based and generic; the base class
// performs the JSON decode (and logs failures) that apply() used to do by hand.
public class PhysicsBlockPropertiesDefinitionLoader extends SimpleJsonResourceReloadListener<PhysicsBlockPropertiesDefinition> {
    public static final String NAME = "physics_block_properties";
    public static final Identifier ID = Sable.sablePath(NAME);

    public static final PhysicsBlockPropertiesDefinitionLoader INSTANCE = new PhysicsBlockPropertiesDefinitionLoader();
    private final ObjectList<PhysicsBlockPropertiesDefinition> definitions = new ObjectArrayList<>();

    private PhysicsBlockPropertiesDefinitionLoader() {
        super(PhysicsBlockPropertiesDefinition.CODEC, FileToIdConverter.json(NAME));
    }

    @Override
    public String getName() {
        return super.getName();
    }

    @Override
    protected void apply(final Map<Identifier, PhysicsBlockPropertiesDefinition> map, final ResourceManager resourceManager, final ProfilerFiller profilerFiller) {
        this.definitions.clear();
        this.definitions.addAll(map.values());

        // Sort by priority
        this.definitions.sort(Comparator.comparingInt(PhysicsBlockPropertiesDefinition::priority));
    }

    /**
     * @return whether any block is registered under the given resource namespace
     */
    private static boolean hasBlocksInNamespace(final String namespace) {
        for (final Identifier id : BuiltInRegistries.BLOCK.keySet()) {
            if (id.getNamespace().equals(namespace)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Applies a singular physics definition to a block or set of blocks
     */
    public static void applyToBlocks(final PhysicsBlockPropertiesDefinition definition) {
        final ExtraCodecs.TagOrElementLocation selector = definition.selector();
        final ObjectArrayList<Block> blocks = new ObjectArrayList<>(16);

        // Selectors may legitimately point at content from an optional mod (Create's
        // flywheel, for instance). When that mod is absent no block exists under its
        // namespace at all, which is a missing dependency rather than a broken datapack
        // -- report it quietly so the real errors stay visible.
        final boolean namespacePresent = hasBlocksInNamespace(selector.id().getNamespace());

        if (selector.tag()) {
            // The selector is a tag, let's pick all blocks
            final TagKey<Block> tagKey = TagKey.create(Registries.BLOCK, selector.id());
            final Optional<HolderSet.Named<Block>> tagBlocks = BuiltInRegistries.BLOCK.get(tagKey);

            if (tagBlocks.isPresent()) {
                final HolderSet.Named<Block> blockHolders = tagBlocks.get();

                for (final Holder<Block> blockHolder : blockHolders) {
                    final Block block = blockHolder.value();

                    blocks.add(block);
                }
            } else if (namespacePresent) {
                Sable.LOGGER.error("Failed to apply tag physics properties. Unknown tag: {}", selector.id());
            } else {
                Sable.LOGGER.debug("Skipping physics properties for {}: namespace {} is not installed", selector.id(), selector.id().getNamespace());
            }
        } else {
            if (BuiltInRegistries.BLOCK.containsKey(selector.id())) {
                // The selector is not a tag, let's just get the block
                final Block block = BuiltInRegistries.BLOCK.getValue(selector.id());
                blocks.add(block);
            } else if (namespacePresent) {
                Sable.LOGGER.error("Failed to apply tag physics properties. Unknown block: {}", selector.id());
            } else {
                Sable.LOGGER.debug("Skipping physics properties for {}: namespace {} is not installed", selector.id(), selector.id().getNamespace());
            }
        }

        for (final Block block : blocks) {
            final StateDefinition<Block, BlockState> stateDefinition = block.getStateDefinition();
            for (final BlockState state : stateDefinition.getPossibleStates()) {
                ((BlockStateExtension) state).sable$loadProperties(stateDefinition, definition);
            }
        }
    }

    /**
     * Applies all registered physics definitions to blocks
     */
    public void applyAll() {
        for (final PhysicsBlockPropertiesDefinition definition : this.definitions) {
            applyToBlocks(definition);
        }
    }

    public Collection<PhysicsBlockPropertiesDefinition> getDefinitions() {
        return this.definitions;
    }
}
