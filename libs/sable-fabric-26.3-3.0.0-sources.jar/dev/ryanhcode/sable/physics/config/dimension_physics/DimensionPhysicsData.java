package dev.ryanhcode.sable.physics.config.dimension_physics;

import dev.ryanhcode.sable.Sable;
import dev.ryanhcode.sable.companion.math.JOMLConversion;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.FileToIdConverter;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimpleJsonResourceReloadListener;
import net.minecraft.util.profiling.ProfilerFiller;
import net.minecraft.world.level.Level;
import org.joml.Vector3d;
import org.joml.Vector3dc;
import org.joml.Vector3fc;

import java.util.HashMap;
import java.util.Map;

public class DimensionPhysicsData {
    static final Map<ResourceKey<Level>, DimensionPhysics> DIMENSION_PHYSICS_DATA = new HashMap<>();
    static final Map<ResourceKey<Level>, DimensionPhysics> DEFAULT_DIMENSION_PHYSICS_DATA = new HashMap<>();

    public static DimensionPhysics of(final Level level) {
        final DimensionPhysics dimensionPhysics = DIMENSION_PHYSICS_DATA.get(level.dimension());
        if (dimensionPhysics == null) {
            return getDefault(level);
        }

        return dimensionPhysics;
    }

    public static DimensionPhysics getDefault(final Level level) {
        DimensionPhysics dimensionPhysics = DEFAULT_DIMENSION_PHYSICS_DATA.get(level.dimension());

        if (dimensionPhysics == null) {
            dimensionPhysics = DimensionPhysics.createDefault(level);
            DEFAULT_DIMENSION_PHYSICS_DATA.put(level.dimension(), dimensionPhysics);
        }

        return dimensionPhysics;
    }

    public static Vector3d getGravity(final Level level) {
        return getGravity(level, JOMLConversion.ZERO);
    }

    public static Vector3d getGravity(final Level level, final Vector3dc pos) {
        return getGravity(level, pos, new Vector3d());
    }

    public static Vector3d getGravity(final Level level, final Vector3dc pos, final Vector3d dest) {
        final DimensionPhysics physics = DimensionPhysicsData.of(level);
        final DimensionPhysics defaultPhysics = getDefault(level);

        final Vector3fc gravity = physics.baseGravity().orElseGet(defaultPhysics.baseGravity()::orElseThrow);
        return dest.set(gravity);
    }

    public static double getAirPressure(final Level level, final Vector3dc pos) {
        final DimensionPhysics physics = DimensionPhysicsData.of(level);
        final DimensionPhysics defaultPhysics = getDefault(level);

        final double pressure = physics.basePressure().orElseGet(defaultPhysics.basePressure()::orElseThrow);
        final BezierResourceFunction curve = physics.pressureFunction().orElseGet(defaultPhysics.pressureFunction()::orElseThrow);

        return pressure * curve.evaluateFunction(pos.y());
    }

    public static Vector3fc getMagneticNorth(final Level level) {
        final DimensionPhysics physics = DimensionPhysicsData.of(level);
        final DimensionPhysics defaultPhysics = getDefault(level);

        return physics.magneticNorth().orElseGet(defaultPhysics.magneticNorth()::orElseThrow);
    }

    public static double getUniversalDrag(final ServerLevel level) {
        final DimensionPhysics physics = DimensionPhysicsData.of(level);
        final DimensionPhysics defaultPhysics = getDefault(level);

        return physics.universalDrag().orElseGet(defaultPhysics.universalDrag()::orElseThrow);
    }

    // PORT-NOTE(mc26.1): SimpleJsonResourceReloadListener is now codec-based and generic; the base class
    // performs the JSON decode (and logs failures) that apply() used to do by hand.
    public static class ReloadListener extends SimpleJsonResourceReloadListener<DimensionPhysics> {

        public static final ReloadListener INSTANCE = new ReloadListener();

        public static final String NAME = "dimension_physics";
        public static final Identifier ID = Sable.sablePath(NAME);

        public ReloadListener() {
            super(DimensionPhysics.CODEC, FileToIdConverter.json(NAME));
        }

        public static void addKeyWithPriority(final Map<ResourceKey<Level>, DimensionPhysics> data, final ResourceKey<Level> key, final DimensionPhysics newProperties) {
            final DimensionPhysics existing = data.get(key);

            if (existing != null) {
                if (newProperties.priority() > existing.priority()) {
                    data.put(key, newProperties);
                }
            } else {
                data.put(key, newProperties);
            }
        }

        @Override
        protected void apply(final Map<Identifier, DimensionPhysics> map, final ResourceManager resourceManager, final ProfilerFiller profiler) {
            DIMENSION_PHYSICS_DATA.clear();

            for (final Map.Entry<Identifier, DimensionPhysics> entry : map.entrySet()) {
                try {
                    final DimensionPhysics dimensionPhysics = entry.getValue();
                    final ResourceKey<Level> dimension = ResourceKey.create(Registries.DIMENSION, dimensionPhysics.dimension());

                    addKeyWithPriority(DIMENSION_PHYSICS_DATA, dimension, dimensionPhysics);
                } catch (final Exception e) {
                    Sable.LOGGER.error("Error while loading dimension data \"{}\" : {} ", entry.getKey(), e.getMessage());
                }
            }
        }
    }
}
