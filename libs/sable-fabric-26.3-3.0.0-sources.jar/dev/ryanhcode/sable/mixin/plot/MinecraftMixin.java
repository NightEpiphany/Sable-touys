package dev.ryanhcode.sable.mixin.plot;

import dev.ryanhcode.sable.SableClient;
import dev.ryanhcode.sable.mixinterface.plot.SubLevelContainerHolder;
import dev.ryanhcode.sable.render.SubLevelDynamicLights;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
public class MinecraftMixin {

    @Shadow @Nullable public ClientLevel level;

    @Shadow private volatile boolean pause;

    @Unique @Nullable private ClientLevel sable$dynamicLightLevel;

    @Inject(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/tutorial/Tutorial;onLookAt(Lnet/minecraft/client/multiplayer/ClientLevel;Lnet/minecraft/world/phys/HitResult;)V"))
    private void sable$tickPlotContainer(final CallbackInfo ci) {
        if (this.sable$dynamicLightLevel != this.level) {
            if (this.sable$dynamicLightLevel != null) {
                SubLevelDynamicLights.clear(this.sable$dynamicLightLevel);
            }
            this.sable$dynamicLightLevel = this.level;
        }

        if (this.level != null) {
            SableClient.NETWORK_EVENT_LOOP.runAllTasks();

            if (!this.pause) {
                ((SubLevelContainerHolder) this.level).sable$getPlotContainer().tick();
            }
            SubLevelDynamicLights.tick(this.level);
        } else {
            SableClient.NETWORK_EVENT_LOOP.clear();
        }
    }
}
