package dev.ryanhcode.sable.mixin.entity.entities_stick_sublevels.player;

import dev.ryanhcode.sable.mixinterface.entity.entities_stick_sublevels.LivingEntityStickExtension;
import net.minecraft.client.player.RemotePlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(RemotePlayer.class)
public abstract class RemotePlayerMixin implements LivingEntityStickExtension {

    @Inject(method = "aiStep", at = @At("HEAD"))
    private void sable$updateRotLerp(final CallbackInfo ci) {
        this.sable$setupLerp();
    }

    // mc26.3: RemotePlayer#aiStep no longer calls updateSwingTime; apply after the step.
    @Inject(method = "aiStep", at = @At("TAIL"))
    private void sable$updateSubLevelPosition(final CallbackInfo ci) {
        this.sable$applyLerp();
    }
}
